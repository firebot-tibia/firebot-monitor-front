$(document).ready(function () {
    $SvgElement = $(SvgElement);
    $SvgElement.on('contextmenu', SVG_MouseDown);
    $('.friendLocation').mousedown(friendMouseDown);
    $('.ManualSelection path').click(ManualSelection_Click).mousemove(ManualSelection_MouseMove).mouseout(ManualSelection_MouseOut);


    gFriend = document.getElementById('gFriend');

    svgAPI = svgPanZoom('#svgMap',
        {
            viewportSelector: '#svgMainGroup'
            , panEnabled: true
            , controlIconsEnabled: false
            , zoomEnabled: true
            , dblClickZoomEnabled: false
            , mouseWheelZoomEnabled: true
            , preventMouseEventsDefault: true
            , zoomScaleSensitivity: 1
            , minZoom: 1
            , maxZoom: 32
            , fit: true
            , contain: true
            , center: true
            , refreshRate: 'auto'
            , beforeZoom: function () {
                if (event.ctrlKey) {
                    event.stopPropagation();
                    event.preventDefault();
                    changeLevel();
                    return false;
                }
            }
            , onZoom: function () {
                if (svgAPI.getZoom() < 5) {
                    $('#svgMapImage').removeClass('pixelatedImage');
                } else {
                    $('#svgMapImage').addClass('pixelatedImage');
                }
            }
            , beforePan: function () {
                if (event.ctrlKey) {
                    return false;
                }
            }
            , onPan: function () { }
            , onUpdatedCTM: function () { }
            , eventsListenerElement: null
        });

})

function changeLevel(newLevel) {
    var levelAtual = SvgElement.getAttribute("level") * 1;

    if (newLevel == undefined) {
        newLevel = levelAtual + Math.sign(event.deltaY);
    }
    if (levelAtual == newLevel) return;

    if (newLevel > 15) newLevel = 15;
    if (newLevel < 0) newLevel = 0;
    document.getElementById('svgMapImage').setAttribute('href', "/img/" + newLevel + ".png");
    SvgElement.setAttribute('level', newLevel);
    $('div.Levels .selected').removeClass('selected');
    $('div.Levels div[l="' + newLevel + '"]').addClass('selected');
}

function btnReset_Click() {
    svgAPI.reset();
    changeLevel(7);
}

function friendMouseDown() {
    event.stopPropagation();
    event.preventDefault();
}
function SVG_MouseDown() {
    if (event.button == 2) {
        event.preventDefault();
        event.stopPropagation();

        var divX = event.pageX - $SvgElement.offset().left;
        var divY = event.pageY - $SvgElement.offset().top;

        var currentPan = svgAPI.getPan();
        var realZoom = svgAPI.getSizes().realZoom;

        var x = Math.trunc((divX - currentPan.x) / realZoom);
        var y = Math.trunc((divY - currentPan.y) / realZoom);

        $(".ManualSelection").show().attr("transform", "translate(" + x + "," + y + ")");
    }
}




function ManualSelection_MouseMove() {
    var text = '';
    switch ($(this).attr('class')) {
        case 'N': text = 'North'; break;
        case 'E': text = 'East'; break;
        case 'S': text = 'South'; break;
        case 'W': text = 'West'; break;
        case 'NE': text = 'North-East'; break;
        case 'NW': text = 'North-West'; break;
        case 'SE': text = 'South-East'; break;
        case 'SW': text = 'South-West'; break;
        case 'fN': text = 'far North'; break;
        case 'fE': text = 'far East'; break;
        case 'fS': text = 'far South'; break;
        case 'fW': text = 'far West'; break;
        case 'fNE': text = 'far North-East'; break;
        case 'fNW': text = 'far North-West'; break;
        case 'fSE': text = 'far South-East'; break;
        case 'fSW': text = 'far South-West'; break;

        case 'vfN': text = 'very far North'; break;
        case 'vfE': text = 'very far East'; break;
        case 'vfS': text = 'very far South'; break;
        case 'vfW': text = 'very far West'; break;
        case 'vfNE': text = 'very far North-East'; break;
        case 'vfNW': text = 'very far North-West'; break;
        case 'vfSE': text = 'very far South-East'; break;
        case 'vfSW': text = 'very far South-West'; break;
        default:
    }
    $('#svgTooltip').show().text(text).css({
        "top": event.pageY, "left": event.pageX + 15
    });
}

function ManualSelection_MouseOut() {
    $('#svgTooltip').hide();
}

function ManualSelection_Click() {
    var translate = $(this).closest(".ManualSelection").attr("transform");
    result = $(this).attr('class');
    AddResult(translate, result, FriendIdCounter++,"manual","em",true);
    $(".ManualSelection").hide();
    $('#svgTooltip').hide();

    Pedido_Click($('.pedido[reqId="em"]'));

}

function SVG_DoubleClick() {
    
    event.preventDefault();
    event.stopPropagation();

    var divX = event.pageX - $SvgElement.offset().left;
    var divY = event.pageY - $SvgElement.offset().top;

    var currentPan = svgAPI.getPan();
    var realZoom = svgAPI.getSizes().realZoom;

    var x = Math.trunc((divX - currentPan.x) / realZoom);
    var y = Math.trunc((divY - currentPan.y) / realZoom);

    SetCurrentLocation(x, y);
    event.stopPropagation();
    event.preventDefault();
}

function SetCurrentLocation(x, y) {
    $('.MyPosition').show().attr("transform", "translate(" + x + "," + y + ")");
    myPosition.x = x;
    myPosition.y = y;
    $('.divMinhaPosicaoTitulo').text("Centralizar").css('cursor', 'pointer').click(CenterOnMyPosition);
}

function CenterOnMyPosition() {
    var div = $(this).closest('.divMinhaPosicao');
    
    var realZoom = svgAPI.getSizes().realZoom;
    svgAPI.pan({
            x: -(myPosition.x * realZoom) + (svgAPI.getSizes().width / 2),
            y: -(myPosition.y * realZoom) + (svgAPI.getSizes().height / 2)
        }); 

}

function AddResult(translate, result, friendID, friendName, reqId, add) {
    var x, y;
    
    if (typeof (translate) == 'string') {
        x = translate.split("(")[1].split(",")[0];
        y = translate.split(",")[1].split(")")[0];
        
    } else {
        x = translate.x;
        y = translate.y;
        translate = "translate(" + x + ", " + y + ")";
        
    }


    if (!add) {
        //Verifica se ja existe um objeto
        $('#svgMap .friends .friend[reqid="' + reqId + '"][friendid="' + friendID + '"]').remove();
    }

    var reqIdPedidoSelecionado = $('.pedido.selected').attr('reqid');

    var clone = $('.friendTemplate').clone(false, false);
    clone.appendTo($('.friends')).removeClass('friendTemplate').addClass(result).attr("transform", translate).attr("friendId", friendID).attr("reqId", reqId);

    if (reqId == reqIdPedidoSelecionado) {
        clone.addClass('selected');
    }

    var circle = document.createElementNS("http://www.w3.org/2000/svg", 'circle');
    circle.setAttributeNS(null, 'cx', x);
    circle.setAttributeNS(null, 'cy', y);
    circle.setAttributeNS(null, 'r', 10);
    circle.setAttribute("friendId", friendID);
    circle.setAttribute("reqId", reqId);
    circle.setAttribute("class", "friendLocation")
    document.querySelector(".friendLocations").appendChild(circle);

    AddResponseItems(reqId, friendID,friendName, result,add);
}

function Level_Click() {
    changeLevel(this.getAttribute('l'));
}
function Level_MouseMove() {
    if (!_LevelMoveActive) return;
    if (event.buttons == 1) {
        changeLevel(this.getAttribute('l'));
    }
}
var _LevelMoveActive = false;
function Level_MouseDown() {
    _LevelMoveActive = true;
}
function Level_MouseUp() {
    _LevelMoveActive = false;
}

$(document).ready(function () {
    $('.Levels > div').click(Level_Click).mousemove(Level_MouseMove).mousedown(Level_MouseDown).mouseup(Level_MouseUp);
    AddRegions();
});

function AddRegions() {
    var regions = getRegions();
    for (var i = 0; i < regions.length; i++) {
        var r = regions[i];

        var rect = document.createElementNS("http://www.w3.org/2000/svg", 'rect');
        rect.setAttributeNS(null, 'x', r.x);
        rect.setAttributeNS(null, 'y', r.y);
        rect.setAttributeNS(null, 'width', r.w);
        rect.setAttributeNS(null, 'height', r.h);
        document.querySelector(".huntPlaces").appendChild(rect);

        var text = document.createElementNS("http://www.w3.org/2000/svg", 'text');
        text.setAttributeNS(null, 'x', r.x+1);
        text.setAttributeNS(null, 'y', r.y+12);
        text.innerHTML = r.name;
        document.querySelector(".huntPlaces").appendChild(text);

        var textBox = text.getBBox();

        var textBg = document.createElementNS("http://www.w3.org/2000/svg", "rect");
        textBg.setAttribute("x", r.x+0.5);
        textBg.setAttribute("y", r.y+0.5);
        textBg.setAttribute("width", textBox.width+2);
        textBg.setAttribute("height", 14);
        textBg.setAttribute("fill", "yellow");
        textBg.classList.add('textBg');
        $('.huntPlaces')[0].insertBefore(textBg, text);

        $('.huntPlaces').append("<text x='"+r.x+"' y='"+r.y+"'>"+r.name+"</text>");
    }
}

function getRegions() {
    return [
        { "x": 978, "y": 1255, "w": 210, "h": 198, "name": "PoI" },
        { "x": 1664, "y": 114, "w": 141, "h": 101, "name": "Fire Portal" },
        { "x": 1714, "y": 406, "w": 162, "h": 119, "name": "Lost Soul - Port Hope" },
        { "x": 1800, "y": 463, "w": 111, "h": 106, "name": "Lost Soul - Vengoth" },
        { "x": 1793, "y": 572, "w": 89, "h": 68, "name": "Nightmare Cave" },
        { "x": 1895, "y": 1291, "w": 85, "h": 76, "name": "WZ 456 Boss Rooms" },
        { "x": 1443, "y": 1123, "w": 166, "h": 113, "name": "WZ 5" },
        { "x": 1058, "y": 1744, "w": 88, "h": 117, "name": "Asura Mirror + True" },
        { "x": 1012, "y": 1705, "w": 138, "h": 125, "name": "Holy Portal" },
        { "x": 823, "y": 1616, "w": 134, "h": 161, "name": "Fire Library" },
        { "x": 679, "y": 1646, "w": 140, "h": 199, "name": "Energy Library" },
        { "x": 707, "y": 1556, "w": 104, "h": 89, "name": "Ice Library" },
        { "x": 679, "y": 1548, "w": 283, "h": 299, "name": "Library" },
        { "x": 1112, "y": 1442, "w": 52, "h": 50, "name": "Deathling Port Hope" },
        { "x": 1156, "y": 1303, "w": 127, "h": 51, "name": "Elite Skeletons" },
        { "x": 2138, "y": 187, "w": 108, "h": 76, "name": "Mirrored Nightmare - Thais Invertida" },
        { "x": 1259, "y": 932, "w": 126, "h": 78, "name": "WZ 2" },
        { "x": 1311, "y": 1246, "w": 124, "h": 122, "name": "Werelion" },
        { "x": 1613, "y": 1339, "w": 86, "h": 99, "name": "Undead Dragon Seal" },
        { "x": 1328, "y": 1097, "w": 310, "h": 154, "name": "Elemental Sphere Quest" },
        { "x": 1623, "y": 1398, "w": 82, "h": 108, "name": "Jugger Seal" },
        { "x": 1668, "y": 1196, "w": 159, "h": 106, "name": "WZ 4" },
        { "x": 1985, "y": 995, "w": 314, "h": 437, "name": "WZ 456" },
        { "x": 1797, "y": 1505, "w": 145, "h": 94, "name": "Buried Cathedral" },
        { "x": 2050, "y": 1475, "w": 153, "h": 112, "name": "The Cube (Inside)" },
        { "x": 1665, "y": 1696, "w": 95, "h": 96, "name": "DT Seal" },
        { "x": 1659, "y": 1584, "w": 104, "h": 98, "name": "Nightmare Isle" },
        { "x": 1591, "y": 1698, "w": 70, "h": 165, "name": "Cobra -1" },
        { "x": 1665, "y": 1793, "w": 95, "h": 65, "name": "Pumin Seal" },
        { "x": 1850, "y": 1633, "w": 110, "h": 135, "name": "Basir Seal" },
        { "x": 350, "y": 1493, "w": 275, "h": 266, "name": "The Spikes" },
        { "x": 664, "y": 1385, "w": 94, "h": 85, "name": "Otherworld - Kaz" },
        { "x": 735, "y": 1343, "w": 99, "h": 161, "name": "Earth Portal - Miguided" },
        { "x": 641, "y": 1413, "w": 262, "h": 148, "name": "Carnisylvans / Yselda" },
        { "x": 1008, "y": 1837, "w": 122, "h": 122, "name": "Energy Portal" },
        { "x": 1084, "y": 1852, "w": 155, "h": 127, "name": "Forg Knowledge Final Portal" },
        { "x": 1455, "y": 1278, "w": 184, "h": 131, "name": "WZ 6" },
        { "x": 229, "y": 932, "w": 171, "h": 147, "name": "Dream Labyrinth" },
        { "x": 1510, "y": 803, "w": 85, "h": 83, "name": "Fury Gate" },
        { "x": 1542, "y": 383, "w": 86, "h": 128, "name": "Caminho Ferumbras" },
        { "x": 1533, "y": 1324, "w": 88, "h": 112, "name": "Ascendant 4 Escadas" },
        { "x": 940, "y": 1504, "w": 216, "h": 185, "name": "Banuta Dungeon" },
        { "x": 1637, "y": 1000, "w": 152, "h": 147, "name": "Abandoned Sewers" },
        { "x": 1618, "y": 950, "w": 394, "h": 69, "name": "Oramond 300/500 Pontos" },
        { "x": 1623, "y": 639, "w": 212, "h": 291, "name": "Renegade Quaras" },
        { "x": 1634, "y": 737, "w": 181, "h": 140, "name": "Catacombs" },
        { "x": 645, "y": 583, "w": 152, "h": 181, "name": "Demona" },
        { "x": 268, "y": 411, "w": 89, "h": 120, "name": "WZ 9" },
        { "x": 423, "y": 255, "w": 186, "h": 170, "name": "GT - Bosses" },
        { "x": 211, "y": 335, "w": 291, "h": 110, "name": "GT - Otherworld" },
        { "x": 143, "y": 356, "w": 113, "h": 116, "name": "Witches Lair" },
        { "x": 1436, "y": 445, "w": 71, "h": 65, "name": "Plague Seal" },
        { "x": 1600, "y": 611, "w": 30, "h": 30, "name": "DT Inq" },
        { "x": 1664, "y": 539, "w": 87, "h": 63, "name": "King Zelos" },
        { "x": 1670, "y": 425, "w": 113, "h": 105, "name": "Bosses Grave D." },
        { "x": 672, "y": 96, "w": 130, "h": 97, "name": "WZ 789 boss/task" },
        { "x": 367, "y": 431, "w": 83, "h": 71, "name": "WZ 8" },
        { "x": 1028, "y": 642, "w": 128, "h": 92, "name": "Death Portal" },
        { "x": 1952, "y": 484, "w": 130, "h": 95, "name": "Bosses Vengoth" },
        { "x": 2138, "y": 267, "w": 101, "h": 152, "name": "Task/Boss Rascaccoon" },
        { "x": 2057, "y": 807, "w": 113, "h": 115, "name": "Alminhas Edron" },
        { "x": 2054, "y": 902, "w": 37, "h": 35, "name": "The Thaian" },
        { "x": 906, "y": 419, "w": 114, "h": 137, "name": "Barkless" }
    ];

}
