var sock;
$(document).ready(function () {

    sock = new WebSocket(SocketAddress + "?i=" + IdUser + "&r=" + IdRoom);
    sock.onopen = function () {
        console.log("sock.onopen");
    }
    sock.onmessage = function (e) {
        console.log("sock.onmessage");
        console.log(e.data);
        sockMessageReceived(e.data);
    }

})

function sockMessageReceived(strMessage) {
    var message = JSON.parse(strMessage);
    switch (message.messageType) {
        case "ExivaResult":
            ExivaResultReceived(message);
            break;
        case "ExivaRequests":
            ExivaRequestReceived(message);
            break;
        case "ConnectionReady":
            sock.send(JSON.stringify({ "messageType": "GetRoomUsers" }));
            break;
        case "UserEnterRoom":
            UserEnterRoom(message.id, message.username);
            break;
        case "UserLeftRoom":
            UserLeftRoom(message.id, message.username);
            break;
        case "GetRoomUsers":
            GetRoomUsers(message.users);
            break;
        default:
            alert("messageType não cadastrado: " + message.messageType);
    }
}
