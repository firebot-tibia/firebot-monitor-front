//////////////////////////////////////////////////////////
// API CALL to get enemies list
//////////////////////////////////////////////////////////
function RefreshEnemies() {
    $.getJSON('https://api.tibiadata.com/v2/guild/Ultimo%20Baile.json')
        .done(function (data) {
            console.log('got');
            $('.divEnemies').html('');
            var $enemiesTable = $('<table id="tbEnemies" class="tbEnemies noselect"></table>').appendTo($('.divEnemies'));
            $enemiesTable.append('<tr><th onclick="sortTable(0)"></th><th onclick="sortTable(1)">Nome</th><th onclick="sortTable(2)">Voc</th><th onclick="sortTable(3,true)">LVL</th></tr>');
            for (var r = 0; r < data.guild.members.length; r++) {
                var rank = data.guild.members[r];
                console.log('rank ' + rank.rank_title);
                for (var m = 0; m < rank.characters.length; m++) {
                    var member = rank.characters[m];
                    if (member.status == 'online') {
                        AddRow($enemiesTable, member.name, ShortVocation(member.vocation), member.level);
                    }
                }
            }

            $enemiesTable.find('tr')
                .mousedown(EnemiesTableTr_MouseDown)
                .mousemove(EnemiesTableTr_MouseMove)
                .mouseup(EnemiesTableTr_MouseUp)
                .children('td').on('contextmenu', EnemiesTableTr_ContextMenu);
        })
        .fail(function (data) { alert(data); })
}

function ShortVocation(voc) {
    if (voc.indexOf('ruid') > 0) return "ED";
    if (voc.indexOf('orce') > 0) return "MS";
    if (voc.indexOf('night') > 0) return "EK";
    if (voc.indexOf('ladin') > 0) return "RP";
}

function AddRow($tb, name, voc, level, v4) {
    //verifica se está nos favoritos
    if (Favoritos.indexOf(name) > -1)
        $tb.append('<tr charname="' + name + '"><td class="tdFav fav" onclick="ToggleFav(this);">F</td><td>' + name + '</td><td>' + voc + '</td><td>' + level + '</td></tr>');
    else
        $tb.append('<tr charname="' + name + '"><td class="tdFav" onclick="ToggleFav(this);">N</td><td>' + name + '</td><td>' + voc + '</td><td>' + level + '</td></tr>');
}



/////////////////////////////////////////////////////////////////////
// Table Selection || Context menu
/////////////////////////////////////////////////////////////////////



var EnemiesTrMouseDownIndex = null;
function EnemiesTableTr_ContextMenu() {
    $('#tbEnemiesContextMenu').css({ top: event.pageY, left: event.pageX }).show();
    event.preventDefault();
    event.stopPropagation();
}

function EnemiesTableTr_MouseDown() {
    if (event.buttons != 1) return;
    var $this = $(this);
    var $table = $this.closest('table');
    if (!event.ctrlKey) {
        $table.find('.selected').removeClass('selected');
    }
    EnemiesTrMouseDownIndex = $table.children('tr').index(this);
    if (EnemiesTrMouseDownIndex == 0) {
        EnemiesTrMouseDownIndex = 1;
    }
    $this.addClass('selectTemp');
}

function EnemiesTableTr_MouseMove() {
    if (event.buttons != 1) return;
    var $this = $(this);
    var $table = $this.closest('table');
    var $trs = $table.children('tr');
    var iniIndex = EnemiesTrMouseDownIndex;
    var fimIndex = $trs.index(this);
    if (iniIndex > fimIndex) {
        //inverte
        var b = iniIndex;
        iniIndex = fimIndex;
        fimIndex = b;
    }
    if (iniIndex == 0) iniIndex = 1;
    for (var i = 1; i < iniIndex; i++) {
        $trs.eq(i).removeClass("selectTemp");
    }
    for (var i = iniIndex; i <= fimIndex; i++) {
        $trs.eq(i).addClass("selectTemp");
    }
    for (var i = fimIndex + 1; i < $trs.length; i++) {
        $trs.eq(i).removeClass("selectTemp");
    }

}


function EnemiesTableTr_MouseUp() {
    $('.selectTemp').removeClass('selectTemp').addClass('selected');
}

$(document).ready(function () {
    $('body').mouseup(EnemiesTableTr_MouseUp);
})




////////////////////////////////////////////////////////////////
/// SORT
////////////////////////////////////////////////////////////////


function sortTable(n, isNumber) {
    var table, rows, switching, i, x, y, shouldSwitch, dir, v1, v2, switchcount = 0;
    table = document.getElementById("tbEnemies");
    switching = true;
    // Set the sorting direction to ascending:
    dir = "asc";
    /* Make a loop that will continue until
    no switching has been done: */
    while (switching) {
        // Start by saying: no switching is done:
        switching = false;
        rows = table.rows;
        /* Loop through all table rows (except the
        first, which contains table headers): */
        for (i = 1; i < (rows.length - 1); i++) {
            // Start by saying there should be no switching:
            shouldSwitch = false;
            /* Get the two elements you want to compare,
            one from current row and one from the next: */
            x = rows[i].getElementsByTagName("TD")[n];
            y = rows[i + 1].getElementsByTagName("TD")[n];
            /* Check if the two rows should switch place,
            based on the direction, asc or desc: */
            v1 = x.innerHTML.toLowerCase();
            v2 = y.innerHTML.toLowerCase();
            if (isNumber) {
                v1 -= 0;
                v2 -= 0;
            }
            if (dir == "asc") {
                if (v1 > v2) {
                    // If so, mark as a switch and break the loop:
                    shouldSwitch = true;
                    break;
                }
            } else if (dir == "desc") {
                if (v1 < v2) {
                    // If so, mark as a switch and break the loop:
                    shouldSwitch = true;
                    break;
                }
            }
        }
        if (shouldSwitch) {
            /* If a switch has been marked, make the switch
            and mark that a switch has been done: */
            rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
            switching = true;
            // Each time a switch is done, increase this count by 1:
            switchcount++;
        } else {
            /* If no switching has been done AND the direction is "asc",
            set the direction to "desc" and run the while loop again. */
            if (switchcount == 0 && dir == "asc") {
                dir = "desc";
                switching = true;
            }
        }
    }
}






//////////////////////////////////////
////// FAVORITOS
//////////////////////////////////////

var Favoritos = [];
strFavoritos = localStorage.getItem('Favoritos');

if (strFavoritos == undefined) {
    Favoritos = [];
} else {
    Favoritos = JSON.parse(strFavoritos);
}

function ToggleFav(obj) {
    var $obj = $(obj);
    var charname = $obj.closest('tr').attr('charname');
    if ($obj.hasClass('fav')) {
        $obj.removeClass('fav');
        $obj.text("N")
        var i = Favoritos.indexOf(charname);
        Favoritos.splice(i, 1);
    } else {
        $obj.addClass('fav');
        $obj.text("F")
        Favoritos.push(charname);
    }
    localStorage.setItem('Favoritos', JSON.stringify(Favoritos));
}

function tbEnemiesContextMenu_Click() {
   
    var charnames = [];
    $('.tbEnemies tr.selected').each(function (tr) {
        charnames.push($(this).attr('charname'));
    });
    AddRequests(charnames);
}

function AddRequests(charnames) {

    var req = {
        messageType: "ExivaRequests",
        requests: []
    };

    for (var i = 0; i < charnames.length; i++) {
        req.requests.push({ "reqId": IdUser + '' + (Date.now() * 1 + i), "charname": charnames[i] })
    }

    sock.send(JSON.stringify(req));

    AddRequestItems(req.requests);

    $("#tbEnemiesContextMenu").hide();
}




function SolicitarTodos() {

    var t = $('#txtEnemies').val();
    var lines = t.split('\n');
    var arrCharNames = [];
    for (var i = 0; i < lines.length; i++) {
        var charname = lines[i].trim();
        if (charname.length > 3) {
            if (arrCharNames.indexOf(charname) == -1) { 
                arrCharNames.push(charname);
            }
        }
    }
    AddRequests(arrCharNames);
}

